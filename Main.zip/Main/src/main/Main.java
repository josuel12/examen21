/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

/**
 *
 * @author Rodrigo
 */
import javax.swing.JOptionPane;

class CinemaApp {
    private String nombrePelicula;
    private char[][] asientos;

    public CinemaApp() {
        asientos = new char[5][10];
        for (int i = 0; i < asientos.length; i++) {
            for (int j = 0; j < asientos[i].length; j++) {
                asientos[i][j] = ' ';
            }
        }
        nombrePelicula = "No hay película programada";
    }

    public void mostrarAsientos() {
        StringBuilder visualizacionAsientos = new StringBuilder();
        visualizacionAsientos.append("Película: ").append(nombrePelicula).append("\n");
        visualizacionAsientos.append("  0 1 2 3 4 5 6 7 8 9\n");
        for (int i = 0; i < asientos.length; i++) {
            visualizacionAsientos.append((char) ('A' + i)).append(" ");
            for (int j = 0; j < asientos[i].length; j++) {
                visualizacionAsientos.append(asientos[i][j]).append(" ");
            }
            visualizacionAsientos.append("\n");
        }
        JOptionPane.showMessageDialog(null, visualizacionAsientos.toString(), "Sistema de Gestión de Cine en la Oficina", JOptionPane.PLAIN_MESSAGE);
    }

    public void cambiarNombrePelicula(String nuevoNombrePelicula) {
        nombrePelicula = nuevoNombrePelicula;
    }

    public void asignarAsiento(int fila, int columna) {
        if (asientos[fila][columna] == ' ') {
            asientos[fila][columna] = 'X';
            JOptionPane.showMessageDialog(null, "Asiento asignado correctamente.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Este asiento ya está ocupado.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.WARNING_MESSAGE);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        CinemaApp app = new CinemaApp();
        while (true) {
            String[] opciones = { "Mostrar asientos", "Cambiar nombre de la película", "Asignar asiento", "Salir" };
            int eleccion = JOptionPane.showOptionDialog(null, "Bienvenido al Sistema de Gestión de Cine en la Oficina", "Sistema de Gestión de Cine en la Oficina", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, opciones, opciones[0]);

            switch (eleccion) {
                case 0:
                    app.mostrarAsientos();
                    break;
                case 1:
                    String nuevoNombrePelicula = JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre de la película:", "Sistema de Gestión de Cine en la Oficina", JOptionPane.QUESTION_MESSAGE);
                    app.cambiarNombrePelicula(nuevoNombrePelicula);
                    JOptionPane.showMessageDialog(null, "Nombre de la película cambiado exitosamente.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2:
                    String filaInput = JOptionPane.showInputDialog(null, "Ingrese la letra de la fila (A-E):", "Sistema de Gestión de Cine en la Oficina", JOptionPane.QUESTION_MESSAGE);
                    char fila = filaInput.toUpperCase().charAt(0);
                    if (fila < 'A' || fila > 'E') {
                        JOptionPane.showMessageDialog(null, "Letra de fila inválida. Por favor ingrese una letra entre A y E.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                    String columnaInput = JOptionPane.showInputDialog(null, "Ingrese el número de columna (0-9):", "Sistema de Gestión de Cine en la Oficina", JOptionPane.QUESTION_MESSAGE);
                    int columna = Integer.parseInt(columnaInput);
                    if (columna < 0 || columna > 9) {
                        JOptionPane.showMessageDialog(null, "Número de columna inválido. Por favor ingrese un número entre 0 y 9.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                    app.asignarAsiento(fila - 'A', columna);
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Gracias por usar el Sistema de Gestión de Cine en la Oficina. ¡Adiós!", "Sistema de Gestión de Cine en la Oficina", JOptionPane.INFORMATION_MESSAGE);
                    return;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Por favor intente de nuevo.", "Sistema de Gestión de Cine en la Oficina", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
